package com.niit.ecartweb.dao;

import java.util.List;

import com.niit.ecartweb.model.Cart;




public interface CartDAO {


	public List<Cart> list(String id);

	public Cart get(String id);
	public void saveOrUpdate(Cart Cart);

	public String delete(int id);
	
	public long getTotalAmount(String id);


}
