package com.niit.ecartweb.dao;

import java.util.List;

import com.niit.ecartweb.model.Category;

public interface CategoryDAO {
	
	public Category get(String id);
	public void saveOrUpdate(Category category);
	public void delete(String id);
	public Category getByName(String name);

	public List<Category> list();
}
