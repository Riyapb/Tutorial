package com.niit.ecartweb;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.ProductDAO;
import com.niit.ecartweb.model.Product;

public class ProductTest {
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		Product product=(Product) context.getBean("product");
		
		product.setId("002");
		product.setName("Micromax");
		product.setDescription("micromax mobile");
		product.setPrice(10000);
		
		productDAO.saveOrUpdate(product);
		
		//productDAO.delete("1234");
		System.out.println(productDAO.get("001").getName());
		
	}

}
