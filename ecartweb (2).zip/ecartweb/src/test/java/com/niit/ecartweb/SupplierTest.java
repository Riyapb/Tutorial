package com.niit.ecartweb;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.SupplierDAO;
import com.niit.ecartweb.model.Supplier;

public class SupplierTest {
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		SupplierDAO supplierDAO=(SupplierDAO) context.getBean("supplierDAO");
		Supplier supplier=(Supplier) context.getBean("supplier");
		
		supplier.setId("124");
		supplier.setName("Mobile");
		supplier.setAddress("marathalli");
		supplier.setMobile_no("8765432190");
		
		supplierDAO.saveOrUpdate(supplier);
		
		//supplierDAO.delete("1234");
		System.out.println(supplierDAO.get("124").getName());
		
	}

}
