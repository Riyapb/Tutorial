package com.niit.ecartweb.dao;

import java.util.List;
import com.niit.ecartweb.model.UserDetails;

public interface UserDAO {
	
	public UserDetails get(String id);
	public void saveOrUpdate(UserDetails userDetails);
	public void delete(String id);
	public List<UserDetails> list();
	public boolean isValidUser(String name,String password);

}
