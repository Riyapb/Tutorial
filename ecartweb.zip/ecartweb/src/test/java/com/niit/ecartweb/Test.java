package com.niit.ecartweb;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.CategoryDAO;
import com.niit.ecartweb.model.Category;

public class Test {
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		CategoryDAO categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
		Category category=(Category) context.getBean("category");
		
		category.setId("1234");
		category.setName("Mobile");
		category.setDescription("Mobile category");
		
		categoryDAO.saveOrUpdate(category);
		
		//categoryDAO.delete("1234");
		System.out.println(categoryDAO.get("134").getDescription());
		
	}

}
