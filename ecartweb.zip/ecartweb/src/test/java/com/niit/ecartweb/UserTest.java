package com.niit.ecartweb;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.UserDAO;

import com.niit.ecartweb.model.UserDetails;

public class UserTest {
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		UserDAO userDAO=(UserDAO) context.getBean("userDAO");
		UserDetails user=(UserDetails) context.getBean("user");
		
		user.setId("001");
		user.setName("Riya");
		user.setPassword("ascfadg");
		user.setMail("riya14497@gmail.com");
		user.setAddress("Sanjaynagar");
		user.setMobile_no("912345678");
		
		userDAO.saveOrUpdate(user);
		
		//userDAO.delete("1234");
		//System.out.println(userDAO.get("124").getName());
		
	}

}