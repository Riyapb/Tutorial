package com.niit.mvc;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Controller() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method s
		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		LoginDAO login=new LoginDAO();
		RequestDispatcher dispatcher;
			
			
		if(login.isValidUser(userid,password)==true)
		{
			dispatcher=request.getRequestDispatcher("Home.html");
			dispatcher.forward(request,response);
		}
		else{
			dispatcher=request.getRequestDispatcher("index.html");
			PrintWriter writer=response.getWriter();
			writer.append("error has occured");
			dispatcher.include(request,response);
			
		}
		
		
	}

}
