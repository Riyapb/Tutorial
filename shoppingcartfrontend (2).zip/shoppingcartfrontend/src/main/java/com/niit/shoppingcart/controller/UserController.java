package com.niit.shoppingcart.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ecartweb.dao.CartDAO;
import com.niit.ecartweb.dao.CategoryDAO;
import com.niit.ecartweb.dao.UserDAO;
import com.niit.ecartweb.model.Cart;
import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.UserDetails;






@Controller
public class UserController {
	@Autowired
	Category category;
	@Autowired
	CategoryDAO categoryDAO;
	@Autowired
	UserDAO userDAO;
	
@Autowired 
Cart cart;
@Autowired
CartDAO cartDAO;
	@Autowired
	UserDetails userDetails;

	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session){
		
		ModelAndView mv=new ModelAndView("/index");
		session.setAttribute("category", category);
		session.setAttribute("categoryList",categoryDAO.list());
		return mv;
	}
	
	
	@RequestMapping(value="user/register",method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute UserDetails userDetails)
	{
		userDAO.saveOrUpdate(userDetails);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage","you are successfully registered");
		return mv;
	}
	
	@RequestMapping("/Signup")
	public ModelAndView signup() {
		ModelAndView mv = new ModelAndView("/index");
		mv.addObject("userDetails", userDetails);
		mv.addObject("isUserClickedRegisterHere", "true");
		return mv;
	}
	
	
	
	

	@RequestMapping("/Login")
	public String getLogin(){
		return "Login";
		}
	
@RequestMapping("/check")
public ModelAndView Login(@RequestParam(name="name")String name,@RequestParam(name="password")String password,HttpSession session){
	ModelAndView mv;
	
	
	boolean isValidUser=userDAO.isValidUser(name, password);
	if(isValidUser){
		userDetails=userDAO.get(name);
	
		session.setAttribute("loggedInUser",userDetails.getName());
		session.setAttribute("loggedInUserId",userDetails.getId());
		
		
		if(userDetails.getAdmin()==1){
			mv=new ModelAndView("/adminHome");
			mv.addObject("message","welcome admin"+userDetails.getName());
			
		}
		else{
			mv=new ModelAndView("/index");
			mv.addObject("message", "welcome"+userDetails.getName());
			   cart = cartDAO.get(name);
		     				mv.addObject("cart", cart);
		       				List<Cart> cartList = cartDAO.list(name);
	         				mv.addObject("cartList", cartList);
	           				mv.addObject("cartSize", cartList.size());
		}}
	else {
		mv=new ModelAndView("/Login");
		mv.addObject("message", "invalid user");
		
	}
	return mv;
}

}
