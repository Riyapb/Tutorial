package com.niit.shoppingcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.ecartweb.dao.CartDAO;
import com.niit.ecartweb.dao.CategoryDAO;
import com.niit.ecartweb.dao.ProductDAO;
import com.niit.ecartweb.model.Cart;
import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.Product;

@Controller
public class CartController {
	
	@Autowired
	Cart cart;
	@Autowired(required=true)
	private CartDAO cartDAO;
	
	@Autowired(required=true)
	private ProductDAO productDAO;
	
	@Autowired(required=true)
	private CategoryDAO categoryDAO;

	
	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String myCart(Model model,HttpSession session) {
		
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", categoryDAO.list());
	
		model.addAttribute("cart", cart);
		String loggedInUserid=(String) session.getAttribute("loggedInUserId");
		model.addAttribute("cartList", cartDAO.list(loggedInUserid));
		//model.addAttribute("totalAmount", cartDAO.list(loggedInUserid));
		//model.addAttribute("cartList", this.cartDAO.list());
		model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid)); // Just to test, password user
		model.addAttribute("displayCart", "true");
		return "cart";
	}
	
	
	/*@RequestMapping(value = "/carts", method = RequestMethod.GET)
	public String listCarts(Model model) {
		model.addAttribute("cart", new Cart());
		model.addAttribute("cartList", this.cartDAO.list());
		return "cart";
	}*/
	
	
	//For add and update cart both
	@RequestMapping(value= "product/get/cart/add/{id}", method = RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id){
		
	
	 Product product =	 productDAO.get(id);
	 Cart cart = new Cart();
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 cart.setQuantity(1);
	 cart.setUserID("userID");
	// String loggedInUserid=(String) session.getAttribute("loggedInUserId");
	   //  id should keep session and use the same id
	 cart.setStatus('N');  // 
		cartDAO.saveOrUpdate(cart);
		//return "redirect:/views/index.jsp";
		return "cart";
		
	}
	
	@RequestMapping("cart/delete/{id}")
    public String removeCart(@PathVariable("id") int id,ModelMap model) throws Exception{
		
       try {
		cartDAO.delete(id);
		model.addAttribute("message","Successfully removed");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/cart";
    }
 
    @RequestMapping("cart/edit/{id}")
    public String editCart(@PathVariable("id") String id, Model model){
    	System.out.println("editCart");
        model.addAttribute("cart", this.cartDAO.get(id));
        model.addAttribute("listCarts", this.cartDAO.list(id));
        return "cart";
    }
}
